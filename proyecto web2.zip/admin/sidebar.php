<link rel="stylesheet" href="admin_sidebar.css">

<div class="sidebar">
    <div style="text-align: center; padding: 10px 0;">
        <i class="fas fa-paw fa-2x"></i>
        <h2 style="margin: 10px 0; font-size: 1.2em;">Pet House Admin</h2>
    </div>
    <a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
    <a href="productos.php"><i class="fas fa-box"></i> Productos</a>
    <a href="citas.php"><i class="fas fa-calendar-check"></i> Citas</a>
    <a href="usuarios.php"><i class="fas fa-users"></i> Usuarios</a>
    <a href="contactos.php"><i class="fas fa-envelope"></i> Contactos</a>
    <a href="../php/cerrar.php" style="margin-top:auto; background:#e74c3c;"><i class="fas fa-sign-out-alt"></i> Cerrar sesión</a>
</div>
